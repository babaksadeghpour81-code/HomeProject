from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('properties.urls')),
    path('accounts/', include('accounts.urls')),
    path('agencies/', include('agencies.urls')),
    path('support/', include('support.urls')),
]

# در حالت توسعه اجازه دسترسی به فایل‌های media و static
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)